<aside>
    <article>
        <h1>
            Menu Du Mois
        </h1>
        <img src="<?= ROOT ?>images/burgermois.jpg" alt="Burger">
        <h2> A hauteur de 18 euros Vous pourrez vous payez un burger excellent composé d'ingredient prestigieux tel que de la truffe ainsi que du caviard avce nos frites maisons.</h2>
    </article>
</aside>
<footer>
       <h2> N'hesitez pas a nous contacter et laisser votre avis sur notre restaurant sur les réseaux sociaux :</h2>
       <a href="https://www.instagram.com/william_.pscl?igsh=OWNyN3E2MW9tYzEx&utm_source=qr">
        <img src="<?= ROOT ?>images/insta.png" alt="Instagram,réseaux,Influenceur"> 
        </a>
       <a href="https://www.linkedin.com/in/gregory-raffoux/">
        <img src="<?= ROOT ?>images/LinkedinBlack.png" alt="Linkedin,réseau,Travail"> 
        </a>
        <a href="https://www.facebook.com">
        <img src="<?= ROOT ?>images/facebook" alt="Facebook,réseaux,rencontres"> 
        </a>

        <h2> &copy; Copyright </h2>
</footer>   
</body>
</html>