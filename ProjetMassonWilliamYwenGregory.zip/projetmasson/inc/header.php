<?php
session_start();
define('ROOT', '/projetmasson/');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <title>Contrôle PHP</title>
    <meta charset="UTF-8">
    <meta name="descritpion" content="test maison 1">
    <link rel="stylesheet" href="<?= ROOT ?>css/style.css">
    <link rel="stylesheet" href="<?= ROOT ?>css/mobile.css">
</head>
<body>
    <header>
        <h1>
            <a href="<?= ROOT ?>index.php">
                <img src="<?= ROOT ?>images/efreisto.png" alt="Logo Efreisto">
            </a>
        </h1>
        <h1>
            L'efreisto
        </h1>
        <form action="<?= ROOT ?>pages/traitement.php" method="get">
            <input type="search" name="recherche" maxlength="200" placeholder="Recherche...">
            <input type="image" src="<?= ROOT ?>images/loupe.png">
        </form>
    </header>
    <nav>
        <a href="<?= ROOT ?>index.php">Accueil</a>
        <a href="<?= ROOT ?>pages/menu.php">Menu</a>
        <a href="<?= ROOT ?>pages/reservation.php">Reserver</a>
        <a href="<?= ROOT ?>pages/edit.php">Réservation</a>

    </nav>