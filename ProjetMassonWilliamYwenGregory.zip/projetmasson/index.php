<?php include 'inc/header.php';?>
    <main>  

        <h1>Qui sommes nous ?</h1>
         <div class="image resto">
            <img src="<?= ROOT ?>images/resto" alt="Image du restaurant" />
            <h3>Un restaurant gastronomique né d'une passion commune</h3>
        <p>Créé par trois amis d'université, L'efreisto n'est pas seulement un restaurant, mais une aventure humaine. Ces trois passionnés ont décidé de tout quitter pour se consacrer à leur véritable amour : la gastronomie.</p>
        <h2>Notre Histoire</h2>
        <p>
            L'aventure de L'efreisto a commencé sur les bancs de l'université. Trois amis, chacun avec une passion différente pour la cuisine, ont décidé de fusionner leurs talents et de tout lâcher pour ouvrir un restaurant où la passion se reflète dans chaque plat. Leurs parcours, divers mais complémentaires, les ont conduits à réaliser un rêve commun : offrir une expérience gastronomique inoubliable, qui soit à la fois audacieuse, raffinée et pleine de sens.
        </p>



        <h2>Une Cuisine Gastronomique Unique</h2>
        <p>
            Chez L'efreisto, chaque plat est une œuvre d'art, réalisée avec des produits frais, locaux, et une maîtrise parfaite des techniques culinaires. Nos chefs mélangent tradition et innovation, et chaque recette est pensée pour surprendre, émouvoir et ravir vos papilles. Notre carte évolue en fonction des saisons, vous garantissant des expériences uniques à chaque visite.
        </p>



        <h2>Notre Vision</h2>
        <p>
            L'efreisto, c'est bien plus qu'un restaurant. C'est un lieu où la passion prend vie, où les amis se transforment en partenaires et où l'amour de la cuisine devient un véritable art de vivre. Nous croyons fermement que la gastronomie doit toucher toutes les émotions, de la surprise à l'émerveillement. En partageant nos plats, nous partageons notre histoire, notre vision et notre amitié avec vous.
        </p>


        <h2>Rejoignez-nous</h2>
        <p>
            Venez vivre une expérience culinaire hors du commun. L'efreisto vous accueille pour un voyage gustatif unique, dans un cadre à la fois moderne et chaleureux. Nous avons hâte de partager avec vous ce que nous avons créé avec amour et passion.
        </p>
    </div>
</main>
    </div>
    </main>
<?php include 'inc/footer.php';


// raccourcis pour ecrire le header, le main , la nav et le footer sur une ligne : header+nav+main+footer