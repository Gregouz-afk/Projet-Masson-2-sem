CREATE DATABASE efreisto ;
use efreisto
CREATE TABLE clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prenom VARCHAR(100),
    nom VARCHAR(100),
    email VARCHAR(150),
    confirmation_email VARCHAR(150),
    reservation_date date
);


