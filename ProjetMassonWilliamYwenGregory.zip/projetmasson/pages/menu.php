<?php include '../inc/header.php';?>
    <main>
        <h1>Nos Menus Phares</h1>

        <h2>
            🌟 Plats Phares (Signature)
        </h2>



        <?php

$menuphare = array(

    array('Filet de bœuf Rossini, purée truffée',29),
    array('Risotto crémeux aux cèpes et parmesan affiné',21),
    array('Poulpe grillé, écrasé de pommes de terre fumées, huile vierge au citron',25),
    array('Curry thaï aux gambas et lait de coco, riz jasmin',22)

);

echo '<dl>';

for ($i=0; $i<count($menuphare); $i++):

    echo '<dt>' . $menuphare[$i][0] . '</dt>';
    echo '<dd>' . $menuphare[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>

    <h1>
        🍽️ Menu Gastronomique (formule ou à la carte)
    </h1>
    <h2>
        🧀 Entrées (6 au choix)
    </h2>

    <?php

$menugastro = array(

    array('Tartare de saumon, mangue & avocat',11),
    array('Œuf parfait, crème de champignons & croustillant de pain',9),
    array('Burrata crémeuse, tomates anciennes & pesto maison',10),
    array('Carpaccio de bœuf, roquette & copeaux de parmesan',12),
    array('Velouté de potimarron, éclats de noisettes',8),
    array('Tataki de thon, sésame & sauce soja agrume',13)
    

);

echo '<dl>';

for ($i=0; $i<count($menuphare); $i++):

    echo '<dt>' . $menuphare[$i][0] . '</dt>';
    echo '<dd>' . $menuphare[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
<h2>
    🍝 Plats (10 au choix)
</h2>

<?php

$plats = array(

    array('Magret de canard, purée de patate douce, jus au miel',22),
    array('Dos de cabillaud en croûte d’herbes, risotto citronné',21),
    array('Burger maison au cheddar affiné, frites de patate douce',17),
    array('Tagliatelles fraîches aux truffes & parmesan',19),
    array('Filet mignon de porc, polenta crémeuse & légumes rôtis',20),
    array('Lasagnes végétariennes au chèvre & légumes grillés',16)
    
    

);

echo '<dl>';

for ($i=0; $i<count($plats); $i++):

    echo '<dt>' . $plats[$i][0] . '</dt>';
    echo '<dd>' . $plats[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
<h2>
    🍰 Desserts (3 au choix)
</h2>
<?php

$dessert = array(

    array('Fondant au chocolat cœur coulant, glace vanille',8),
    array('Tartelette citron meringuée revisitée',7),
    array('Panna cotta coco & coulis de fruits rouges',7)

);

echo '<dl>';

for ($i=0; $i<count($dessert); $i++):

    echo '<dt>' . $dessert[$i][0] . '</dt>';
    echo '<dd>' . $dessert[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
<h1>
    🍷 Carte des Boissons (à part)
</h1>
<h2>
    🥂 Apéritifs
</h2>

<?php

$boiss = array(

    array('Spritz',6),
    array('Kir royal',7),
    array('Mojito classique',8),
    array('Martini blanc / rouge',5)

);

echo '<dl>';

for ($i=0; $i<count($boiss); $i++):

    echo '<dt>' . $boiss[$i][0] . '</dt>';
    echo '<dd>' . $boiss[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>

<h2>
    🍷 Vins
</h2>
<h3>
    Rouges :
</h3>


<?php

$rouge = array(

    array('Bordeaux Château Bellegrave',22),
    array('Côtes-du-Rhône bio',20)

);

echo '<dl>';

for ($i=0; $i<count($rouge); $i++):

    echo '<dt>' . $rouge[$i][0] . '</dt>';
    echo '<dd>' . $rouge[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
<h3>
    Blancs :
</h3>
<?php

$blanc = array(

    array('Bordeaux Château Bellegrave',28),
    array('Côtes-du-Rhône bio',22)

);

echo '<dl>';

for ($i=0; $i<count($blanc); $i++):

    echo '<dt>' . $blanc[$i][0] . '</dt>';
    echo '<dd>' . $blanc[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
<h3>
    Rosés :
</h3>


<?php

$rose = array(

    array('Coteaux d’Aix',18)

);

echo '<dl>';

for ($i=0; $i<count($rose); $i++):

    echo '<dt>' . $rose[$i][0] . '</dt>';
    echo '<dd>' . $rose[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>

<h2>
    🍺 Bières
</h2>


<?php

$biere = array(

    array('Bière artisanale blonde',6),
    array('IPA locale',7)

);

echo '<dl>';

for ($i=0; $i<count($biere); $i++):

    echo '<dt>' . $biere[$i][0] . '</dt>';
    echo '<dd>' . $biere[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>

<h2>
    🥤 Sans Alcool
</h2>

<?php

$biere = array(

    array('Eau minérale / gazeuse',2),
    array('Jus de fruits artisanaux (pomme, abricot, orange)',4),
    array('Cola / Limonade / Ice Tea',3),
    array('Thé glacé maison',4)

);

echo '<dl>';

for ($i=0; $i<count($biere); $i++):

    echo '<dt>' . $biere[$i][0] . '</dt>';
    echo '<dd>' . $biere[$i][1] . ' €</dd>';
endfor;

echo '</dl>';

?>
    </main>
<?php include '../inc/footer.php';