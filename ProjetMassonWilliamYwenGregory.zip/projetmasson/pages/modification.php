<?php 

$id = $_POST['id'];

include '../inc/cle.php';
$sql = "SELECT * FROM clients WHERE id=$id";

$reponse = $cle->query($sql);

foreach($reponse AS $r): ?>

    <form action="update.php" method="post" >
       <input type="text" name="lastname" id="lastname" value="<?= $r['nom'] ?>" placeholder="Nom de famille" maxlength="200"> 
       <input type="text" name="firstname" id="firstname" value="<?= $r['prenom'] ?>" placeholder="Prénom" maxlength="200"> 
       <input type="text" name="email" id="email" value="<?= $r['email'] ?>" placeholder="Email" maxlength="150">
       <input type="date" name="date" id="date" value="<?= $r['reservation_date'] ?>" placeholder="date">
       <input type="hidden" name="id" value="<?= $r['id'] ?>">

       <input type="submit" value="Modifier">
    </form>

    <?php endforeach; ?>