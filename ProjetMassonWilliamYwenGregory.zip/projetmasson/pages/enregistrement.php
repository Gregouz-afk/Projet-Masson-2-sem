<?php
 
if(!empty($_POST['lastname']) && !empty($_POST['firstname']) && !empty($_POST['email']) && !empty($_POST['confirmation_email']) &&  !empty($_POST['reservation_date']))
   
    $nom    = htmlspecialchars($_POST['lastname']);
    $prenom = htmlspecialchars($_POST['firstname']);
    $email = htmlspecialchars($_POST['email']);
    $confirmation_email = htmlspecialchars($_POST['confirmation_email']);
    $date = htmlspecialchars($_POST['reservation_date']);


    $sql = "INSERT INTO clients (nom, prenom, email, confirmation_email, reservation_date, reservation_time) VALUES ('$nom', '$prenom', '$email','$confirmation_email', '$date')";
    echo $sql;

    include '../inc/cle.php';

    $cle->query($sql);

    header('location:OK.php');

else :

    header('Location:../index.php');

endif;