<?php 

if(isset($_POST['lastname'])){

    $nom = htmlspecialchars($_POST['lastname']);
    $prenom = htmlspecialchars($_POST['firstname']);
    $email = htmlspecialchars($_POST['email']);
    $date = isset($_POST['reservation_date']) ? htmlspecialchars($_POST['reservation_date']) : '';      
    $id = htmlspecialchars($_POST['id']);

    include '../inc/cle.php';

    $sql = "UPDATE clients SET nom='$nom', prenom='$prenom', email='$email', reservation_date='$date' WHERE id=$id";
}
    if($cle->query($sql)){
        header('location:edit.php');
    }

