<?php
session_start();
include_once '../inc/cle.php';

if(isset($_POST['lastname'])){

    $nom = htmlspecialchars($_POST['lastname']);
    $prenom = htmlspecialchars($_POST['firstname']);
    $email = htmlspecialchars($_POST['email']);
    $confirmation_email = htmlspecialchars($_POST['confirmation_email']);
    $date = htmlspecialchars($_POST['reservation_date']);
}
    if($email !== $confirmation_email){
        header('Location:reservation.php');
        exit();
    } else {
    $sql = "INSERT INTO clients (nom, prenom, email, confirmation_email, reservation_date) 
        VALUES ('$nom','$prenom','$email','$confirmation_email','$date')";

}

if($cle->query($sql)):
    $_SESSION['message'] = "OK tu es enregistré(e)";
    header('Location:reservation.php');


else:
    header('Location:reservation.php');
endif;
