<?php include '../inc/header.php'; ?>
<main>
    <h2>Liste</h2>

    <table>
        <caption>Liste des inscrits</caption>
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Email</th>
                <th>Date</th>
                <th>Supprimer</th>
                <th>Modifier</th>
            </tr>
        </thead>
        <tbody>

        <?php    
        include '../inc/cle.php';
        
        $query = "SELECT * FROM clients";
        $reponse = $cle->query($query);
        foreach ($reponse as $r): ?>

            <tr>
                <td><?= $r['nom'] ?></td>
                <td><?= $r['prenom'] ?></td>
                <td><?= $r['email'] ?></td>
                <td><?= $r['reservation_date'] ?></td>
                <td>

                


                <form action="suppression.php" method="post">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="image" src="../images/crois.png">
                </form>
            </td>
            <td>
                <form action="modification.php" method="post">
                    <input type="hidden" name="id" value="<?= $r['id'] ?>">
                    <input type="image" src="../images/edit.jpg">
                </form>
            </td>
            </tr>

        <?php endforeach; ?>
        </tbody>
    </table>
</main>
<?php include '../inc/footer.php'; ?>

