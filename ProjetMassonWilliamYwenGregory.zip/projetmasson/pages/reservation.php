<?php include '../inc/header.php';?>
    <main>  
        <h1>Afin de reserver, veuillez remplir ce formulaire. </h1>

            <form action="traitement.php" method="post" >
            <p class="message">
            <?php
             if(isset($_SESSION['message']) && !empty($_SESSION['message'])){
                echo $_SESSION['message'];
                $_SESSION['message'] = '';
             }
             ?>
                <input type="text" name="lastname" placeholder="Nom de famille" maxlength="200" > 
                <input type="text" name="firstname" placeholder="Prénom" maxlength="200" > 
                <input type="text" name="email" placeholder="email" maxlength="150" >
                <input type="text" name="confirmation_email" placeholder="Confirmation de l'email" maxlength="150" >
                <input type="date" name="reservation_date"  >

                <input type="submit" value="Valider votre inscription">
            </form>
    </main>
<?php include '../inc/footer.php';
