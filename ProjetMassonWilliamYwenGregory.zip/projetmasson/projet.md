# Résumé du projet - L'Efreisto

## Organisation des fichiers

- **inc/** : contient les morceaux de page réutilisables comme le haut (`header.php`), le bas (`footer.php`) et la connexion à la base de données (`cle.php`)
- **pages/** : les vraies pages du site comme `menu.php`, `reservation.php`, `edit.php`
- **index.php** : la page d’accueil du site
- **traitement.php**, **enregistrement.php** : s’occupent des formulaires
- **db.sql** : crée la base de données

## Les grandes étapes du site

### 1. Connexion à la base de données

- Fichier : `cle.php`
- Permet de se connecter à la base de données MySQL avec PDO
- Les infos comme le nom d’utilisateur et le mot de passe sont enregistrées dans des constantes pour éviter de les répéter partout

### 2. En-tête et pied de page

- `header.php` et `footer.php` contiennent ce qu’on retrouve en haut et en bas de toutes les pages (comme le logo, la navigation ou les réseaux sociaux)
- On utilise une constante `ROOT` pour que les liens vers les images ou fichiers CSS soient plus faciles à gérer

### 3. Page d'accueil

- Fichier : `index.php`
- Présente le restaurant, son histoire, ses fondateurs(nous), et ce qu'on propose
- Quelques images et beaucoup de texte explicatif

### 4. Menu du restaurant

- Fichier : `menu.php`
- Utilise des tableaux PHP pour afficher les plats et les prix
- Affichage dynamique grâce à des boucles `for`

### 5. Réservation

- Fichier : `reservation.php`
- Formulaire à remplir (nom, prénom, email, date…)
- Quand on clique sur "valider", les données partent vers `traitement.php`

### 6. Enregistrement en base de données

- Fichier : `traitement.php`
- Vérifie que les champs sont remplis
- Insère les infos du formulaire dans la base de données
- Redirige ensuite vers une autre page

### 7. Voir les réservations

- Fichier : `edit.php`
- Affiche les personnes qui ont réservé dans un tableau HTML
- Utilise une requête SQL `SELECT * FROM clients`

### 8. Base de données

- Fichier : `db.sql`
- Crée la base appelée `efreisto`
- Crée une table `clients` avec les colonnes pour le nom, prénom, email, etc.